"""SQLite persistence layer: plans, topics, quiz attempts."""
import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime

DB_PATH = os.getenv("LEARNING_COACH_DB", "learning_coach.db")


class DatabaseError(Exception):
    """Raised for any database failure, with a user-friendly message."""


@contextmanager
def get_conn():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
    except sqlite3.Error as exc:
        raise DatabaseError(f"Could not open the database: {exc}") from exc
    try:
        yield conn
        conn.commit()
    except sqlite3.Error as exc:
        conn.rollback()
        raise DatabaseError(f"Database error: {exc}") from exc
    finally:
        conn.close()


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                subject TEXT NOT NULL,
                goal TEXT NOT NULL,
                level TEXT NOT NULL,
                duration_days INTEGER NOT NULL,
                daily_minutes INTEGER NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS topics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plan_id INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
                day INTEGER NOT NULL,
                title TEXT NOT NULL,
                objectives TEXT NOT NULL,
                estimated_minutes INTEGER NOT NULL,
                activities TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS quiz_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plan_id INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
                topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
                taken_at TEXT NOT NULL,
                score INTEGER NOT NULL,
                total INTEGER NOT NULL,
                percentage REAL NOT NULL,
                questions_json TEXT NOT NULL,
                answers_json TEXT NOT NULL
            );
            """
        )


def save_plan(profile: dict, plan: dict) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO plans (title, subject, goal, level, duration_days, daily_minutes, created_at)"
            " VALUES (?,?,?,?,?,?,?)",
            (plan["title"], profile["subject"], profile["goal"], profile["level"],
             profile["duration_days"], profile["daily_minutes"], _now()),
        )
        plan_id = cur.lastrowid
        for t in plan["topics"]:
            conn.execute(
                "INSERT INTO topics (plan_id, day, title, objectives, estimated_minutes, activities, status, updated_at)"
                " VALUES (?,?,?,?,?,?,?,?)",
                (plan_id, t["day"], t["title"], json.dumps(t["objectives"]),
                 t["estimated_minutes"], json.dumps(t["practice_activities"]), "pending", _now()),
            )
        return plan_id


def list_plans() -> list[dict]:
    with get_conn() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM plans ORDER BY id DESC")]


def get_plan(plan_id: int) -> dict | None:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM plans WHERE id=?", (plan_id,)).fetchone()
        return dict(row) if row else None


def get_latest_plan_id() -> int | None:
    with get_conn() as conn:
        row = conn.execute("SELECT id FROM plans ORDER BY id DESC LIMIT 1").fetchone()
        return row["id"] if row else None


def delete_plan(plan_id: int) -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM plans WHERE id=?", (plan_id,))


def _topic_row(r: sqlite3.Row) -> dict:
    d = dict(r)
    d["objectives"] = json.loads(d["objectives"])
    d["activities"] = json.loads(d["activities"])
    return d


def get_topics(plan_id: int) -> list[dict]:
    """Topics with attempt count, best score and last score (as fractions 0-1)."""
    sql = """
        SELECT t.*,
               COUNT(a.id) AS attempts,
               MAX(a.percentage) AS best_pct,
               (SELECT percentage FROM quiz_attempts q WHERE q.topic_id = t.id
                 ORDER BY q.id DESC LIMIT 1) AS last_pct
        FROM topics t LEFT JOIN quiz_attempts a ON a.topic_id = t.id
        WHERE t.plan_id = ? GROUP BY t.id ORDER BY t.day, t.id
    """
    with get_conn() as conn:
        return [_topic_row(r) for r in conn.execute(sql, (plan_id,))]


def get_topic(topic_id: int) -> dict | None:
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM topics WHERE id=?", (topic_id,)).fetchone()
        return _topic_row(row) if row else None


def save_attempt(plan_id: int, topic_id: int, score: int, total: int,
                 questions: list, answers: list, new_status: str) -> int:
    pct = score / total if total else 0.0
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO quiz_attempts (plan_id, topic_id, taken_at, score, total, percentage,"
            " questions_json, answers_json) VALUES (?,?,?,?,?,?,?,?)",
            (plan_id, topic_id, _now(), score, total, pct,
             json.dumps(questions), json.dumps(answers)),
        )
        conn.execute("UPDATE topics SET status=?, updated_at=? WHERE id=?",
                     (new_status, _now(), topic_id))
        return cur.lastrowid


def get_attempts(plan_id: int, topic_id: int | None = None) -> list[dict]:
    sql = ("SELECT a.id, a.taken_at, a.score, a.total, a.percentage, a.topic_id, t.title AS topic"
           " FROM quiz_attempts a JOIN topics t ON t.id = a.topic_id WHERE a.plan_id = ?")
    params: list = [plan_id]
    if topic_id is not None:
        sql += " AND a.topic_id = ?"
        params.append(topic_id)
    sql += " ORDER BY a.id DESC"
    with get_conn() as conn:
        return [dict(r) for r in conn.execute(sql, params)]
