"""Quiz prompt/validation, Python-side scoring, weak-topic detection, recommendations."""

NUM_QUESTIONS = 5
STRONG_THRESHOLD = 0.8   # >= 80%
WEAK_THRESHOLD = 0.6     # < 60%


def build_quiz_prompt(profile: dict, topic: dict, n: int = NUM_QUESTIONS,
                      harder: bool = False) -> str:
    difficulty = ("Make these questions noticeably harder than a basic check: use "
                  "application and edge-case questions." if harder else
                  f"Match the difficulty to a {profile['level']} learner.")
    return f"""Create a multiple-choice quiz.

Subject: {profile['subject']}
Topic: {topic['title']}
Learning objectives: {'; '.join(topic['objectives'])}
{difficulty}

Rules:
- Exactly {n} questions, each with exactly 4 options.
- Exactly one option is correct. "correct_index" is the 0-based index of that option.
- Give a short "explanation" suited to the learner's level for each question.
- Do not put the letter A/B/C/D inside the option text.

Return JSON with exactly this schema:
{{"questions": [
  {{"question": "...", "options": ["...", "...", "...", "..."],
    "correct_index": 0, "explanation": "..."}}
]}}"""


def make_quiz_validator(n: int = NUM_QUESTIONS):
    def validate(data: dict) -> dict:
        qs = data.get("questions")
        if not isinstance(qs, list) or len(qs) < 1:
            raise ValueError("Quiz must contain a non-empty 'questions' list.")
        clean = []
        for i, q in enumerate(qs[:n], start=1):
            if not isinstance(q, dict):
                raise ValueError(f"Question {i} is not an object.")
            text = str(q.get("question", "")).strip()
            options = q.get("options")
            if not text:
                raise ValueError(f"Question {i} has no text.")
            if not isinstance(options, list) or len(options) != 4:
                raise ValueError(f"Question {i} must have exactly 4 options.")
            options = [str(o).strip() for o in options]
            if any(not o for o in options) or len(set(options)) != 4:
                raise ValueError(f"Question {i} has empty or duplicate options.")
            idx = q.get("correct_index")
            if isinstance(idx, bool) or not isinstance(idx, int) or not 0 <= idx <= 3:
                raise ValueError(f"Question {i} has an invalid 'correct_index'.")
            clean.append({"question": text, "options": options, "correct_index": idx,
                          "explanation": str(q.get("explanation", "")).strip()})
        if len(clean) < n:
            raise ValueError(f"Quiz must contain {n} questions, got {len(clean)}.")
        return {"questions": clean}
    return validate


def generate_quiz(ai, profile: dict, topic: dict, harder: bool = False) -> list[dict]:
    data = ai.generate_validated(build_quiz_prompt(profile, topic, harder=harder),
                                 make_quiz_validator())
    return data["questions"]


def score_quiz(questions: list[dict], answers: list[int | None]) -> dict:
    """Score from the answer key in Python (never by the LLM)."""
    results, score = [], 0
    for q, a in zip(questions, answers):
        correct = a == q["correct_index"]
        score += int(correct)
        results.append({"question": q["question"], "options": q["options"],
                        "chosen": a, "correct_index": q["correct_index"],
                        "is_correct": correct, "explanation": q.get("explanation", "")})
    total = len(questions)
    return {"score": score, "total": total,
            "percentage": score / total if total else 0.0, "results": results}


def status_for(percentage: float) -> str:
    if percentage >= STRONG_THRESHOLD:
        return "completed"
    if percentage < WEAK_THRESHOLD:
        return "needs_revision"
    return "in_progress"


def recommend(topic_title: str, percentage: float, next_topic: str | None) -> dict:
    """Rule-based next step for the quiz just taken."""
    if percentage >= STRONG_THRESHOLD:
        nxt = (f"move on to **{next_topic}**, or try a harder practice quiz on this topic"
               if next_topic else "try a harder practice quiz or review the whole plan")
        return {"level": "strong", "action": "advance",
                "message": (f"Strong result on this quiz. One short quiz is not proof of mastery, "
                            f"but you can {nxt}.")}
    if percentage < WEAK_THRESHOLD:
        return {"level": "weak", "action": "revise",
                "message": (f"**{topic_title}** is flagged for revision. Review the explanations "
                            f"below, redo the practice activities, then retake a quiz.")}
    return {"level": "moderate", "action": "practice",
            "message": (f"You're getting there on **{topic_title}**. Review the questions you "
                        f"missed and take one more quiz before moving on.")}


def build_feedback_prompt(profile: dict, topic: dict, scored: dict) -> str:
    missed = [r["question"] for r in scored["results"] if not r["is_correct"]]
    return f"""A {profile['level']} learner studying {profile['subject']} took a quiz on "{topic['title']}".
They scored {scored['score']} out of {scored['total']} (already calculated; do not recalculate).
Questions answered incorrectly: {missed if missed else 'none'}.

Write 2-3 sentences of encouraging, specific advice on what to practise next.
Do not claim mastery from one quiz.
Return JSON: {{"feedback": "..."}}"""


def next_actions(topics: list[dict]) -> list[str]:
    """Dashboard 'next steps' derived from saved topic statuses."""
    actions = [f"Revise **{t['title']}** (Day {t['day']}) - last quiz below target."
               for t in topics if t["status"] == "needs_revision"]
    actions += [f"Retake a quiz on **{t['title']}** (Day {t['day']}) to build confidence."
                for t in topics if t["status"] == "in_progress"]
    nxt = next((t for t in topics if t["status"] == "pending"), None)
    if nxt:
        actions.append(f"Start **{nxt['title']}** (Day {nxt['day']}).")
    if not actions and topics:
        actions.append("All topics completed. Try harder practice quizzes to consolidate.")
    return actions


def next_pending_topic(topics: list[dict], current_id: int) -> str | None:
    for t in topics:
        if t["id"] != current_id and t["status"] == "pending":
            return t["title"]
    return None
