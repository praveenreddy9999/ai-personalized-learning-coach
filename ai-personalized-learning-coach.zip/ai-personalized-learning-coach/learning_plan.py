"""Study-plan prompt building and validation."""

LEVELS = ["Beginner", "Intermediate", "Advanced"]


def validate_profile(subject: str, goal: str, level: str,
                     duration_days: int, daily_minutes: int) -> list[str]:
    """Return a list of human-readable problems (empty list = valid)."""
    errors = []
    if not (subject or "").strip():
        errors.append("Please enter a subject.")
    if not (goal or "").strip():
        errors.append("Please enter your learning goal.")
    if level not in LEVELS:
        errors.append("Please choose your current level.")
    if not isinstance(duration_days, int) or not 1 <= duration_days <= 60:
        errors.append("Duration must be between 1 and 60 days.")
    if not isinstance(daily_minutes, int) or not 10 <= daily_minutes <= 480:
        errors.append("Daily study time must be between 10 and 480 minutes.")
    return errors


def build_plan_prompt(profile: dict) -> str:
    return f"""Create a day-wise study plan.

Learner profile:
- Subject: {profile['subject']}
- Goal: {profile['goal']}
- Current level: {profile['level']}
- Target duration: {profile['duration_days']} days
- Daily study time: {profile['daily_minutes']} minutes

Rules:
- Produce exactly {profile['duration_days']} entries in "topics", one per day, numbered from 1.
- Content difficulty must suit a {profile['level']} learner.
- Each day's "estimated_minutes" must not exceed {profile['daily_minutes']}.
- Include revision/quiz days near the end when the duration allows.
- Each topic needs 2-4 short "objectives" and 1-3 hands-on "practice_activities".

Return JSON with exactly this schema:
{{
  "title": "short plan title",
  "topics": [
    {{"day": 1, "title": "topic name", "objectives": ["..."],
      "estimated_minutes": 45, "practice_activities": ["..."]}}
  ]
}}"""


def _str_list(value, field: str, day) -> list[str]:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list) or not value:
        raise ValueError(f"Day {day}: '{field}' must be a non-empty list.")
    items = [str(v).strip() for v in value if str(v).strip()]
    if not items:
        raise ValueError(f"Day {day}: '{field}' must contain text.")
    return items


def make_plan_validator(profile: dict):
    """Return a validator that checks and normalises the model's plan JSON."""
    def validate(data: dict) -> dict:
        topics = data.get("topics")
        if not isinstance(topics, list) or not topics:
            raise ValueError("Plan must contain a non-empty 'topics' list.")
        clean = []
        for i, t in enumerate(topics, start=1):
            if not isinstance(t, dict):
                raise ValueError(f"Topic {i} is not an object.")
            title = str(t.get("title", "")).strip()
            if not title:
                raise ValueError(f"Topic {i} has no title.")
            try:
                minutes = int(t.get("estimated_minutes"))
            except (TypeError, ValueError):
                raise ValueError(f"Topic {i} has an invalid 'estimated_minutes'.")
            if minutes <= 0:
                raise ValueError(f"Topic {i} must have positive 'estimated_minutes'.")
            clean.append({
                "day": i,  # renumber so days are always 1..n
                "title": title,
                "objectives": _str_list(t.get("objectives"), "objectives", i),
                "estimated_minutes": min(minutes, profile["daily_minutes"]),
                "practice_activities": _str_list(
                    t.get("practice_activities"), "practice_activities", i),
            })
        clean = clean[: profile["duration_days"]]
        title = str(data.get("title") or f"{profile['subject']} study plan").strip()
        return {"title": title, "topics": clean}
    return validate


def generate_plan(ai, profile: dict) -> dict:
    return ai.generate_validated(build_plan_prompt(profile), make_plan_validator(profile))
