"""LLM integration (Gemini). Handles prompting, JSON parsing, retries and API errors."""
import json
import os
import re
import time
from typing import Callable

from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
SYSTEM_INSTRUCTION = (
    "You are a careful, encouraging learning coach. Always answer with a single valid JSON "
    "object that follows the requested schema exactly, with no markdown and no extra text. "
    "Never claim a learner has mastered a topic based on one short quiz."
)


class AIServiceError(Exception):
    """Raised when the LLM cannot be reached or never returns a valid response."""


def extract_json(text: str) -> dict:
    """Parse JSON from a model reply, tolerating code fences or surrounding text."""
    if not text or not text.strip():
        raise ValueError("The model returned an empty response.")
    cleaned = re.sub(r"```(?:json)?", "", text).strip()
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("The model response did not contain a JSON object.")
    try:
        data = json.loads(cleaned[start:end + 1])
    except json.JSONDecodeError as exc:
        raise ValueError(f"The model returned malformed JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("The model response was not a JSON object.")
    return data


def _gemini_generate(prompt: str) -> str:
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise AIServiceError(
            "No API key found. Copy .env.example to .env and set GEMINI_API_KEY."
        )
    try:
        from google import genai
        from google.genai import types
    except ImportError as exc:
        raise AIServiceError("The 'google-genai' package is not installed.") from exc
    try:
        client = genai.Client(api_key=api_key)
        resp = client.models.generate_content(
            model=DEFAULT_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION,
                response_mime_type="application/json",
                temperature=0.4,
            ),
        )
        return resp.text or ""
    except Exception as exc:  # network, quota, auth, safety blocks...
        raise AIServiceError(f"The AI service request failed: {exc}") from exc


class AIService:
    """Wraps the LLM. `generate_fn` can be injected for tests (prompt -> text)."""

    def __init__(self, generate_fn: Callable[[str], str] | None = None,
                 max_attempts: int = 3, retry_delay: float = 1.0):
        self.generate_fn = generate_fn or _gemini_generate
        self.max_attempts = max_attempts
        self.retry_delay = retry_delay

    def generate_validated(self, prompt: str, validator: Callable[[dict], dict]) -> dict:
        """Call the LLM and validate the output; retry on invalid output or API errors."""
        last_error: Exception | None = None
        for attempt in range(1, self.max_attempts + 1):
            try:
                raw = self.generate_fn(prompt)
                return validator(extract_json(raw))
            except AIServiceError as exc:
                last_error = exc
                if "API key" in str(exc) or "not installed" in str(exc):
                    break  # retrying will not help
            except ValueError as exc:
                last_error = exc
                prompt = (prompt + "\n\nYour previous reply was rejected: "
                          f"{exc} Reply again with ONLY valid JSON in the exact schema.")
            if attempt < self.max_attempts:
                time.sleep(self.retry_delay)
        raise AIServiceError(
            f"Could not get a valid response from the AI. Please try again. ({last_error})"
        )

    def generate_text_feedback(self, prompt: str) -> str | None:
        """Optional personalised study tips. Returns None on any failure (non-critical)."""
        try:
            data = extract_json(self.generate_fn(prompt))
            tips = data.get("feedback")
            return tips.strip() if isinstance(tips, str) and tips.strip() else None
        except Exception:
            return None
