"""AI Personalized Learning Coach - Streamlit UI."""
import pandas as pd
import streamlit as st

import database as db
import learning_plan as lp
import quiz_manager as qm
from ai_service import AIService, AIServiceError

st.set_page_config(page_title="AI Personalized Learning Coach", page_icon="🎓", layout="wide")

STATUS_LABEL = {
    "pending": "⚪ Pending",
    "in_progress": "🟡 In progress",
    "needs_revision": "🔴 Needs revision",
    "completed": "🟢 Completed",
}


# ---------- setup ----------
@st.cache_resource
def get_ai() -> AIService:
    return AIService()


def ss_default(key, value):
    if key not in st.session_state:
        st.session_state[key] = value


try:
    db.init_db()
except db.DatabaseError as exc:
    st.error(f"Database problem: {exc}")
    st.stop()

ss_default("plan_id", db.get_latest_plan_id())
ss_default("quiz", None)        # {"topic_id", "questions", "nonce"}
ss_default("result", None)      # last scored result + recommendation
ss_default("nonce", 0)
ss_default("page", "Home")


def load_plan():
    """Return (plan, topics) for the active plan, or (None, [])."""
    if st.session_state.plan_id is None:
        return None, []
    plan = db.get_plan(st.session_state.plan_id)
    if plan is None:
        st.session_state.plan_id = None
        return None, []
    return plan, db.get_topics(plan["id"])


def need_plan_message():
    st.info("No study plan yet. Go to **Learner Setup** to create one.")


# ---------- sidebar ----------
PAGES = ["Home", "Learner Setup", "Study Plan", "Practice Quiz", "Progress Dashboard"]
with st.sidebar:
    st.title("🎓 Learning Coach")
    page = st.radio("Navigate", PAGES, key="page")
    try:
        plans = db.list_plans()
    except db.DatabaseError as exc:
        plans = []
        st.error(str(exc))
    if plans:
        st.divider()
        ids = [p["id"] for p in plans]
        labels = {p["id"]: f"{p['title']} (#{p['id']})" for p in plans}
        current = st.session_state.plan_id if st.session_state.plan_id in ids else ids[0]
        chosen = st.selectbox("Saved plans", ids, index=ids.index(current),
                              format_func=lambda i: labels[i])
        if chosen != st.session_state.plan_id:
            st.session_state.plan_id = chosen
            st.session_state.quiz = None
            st.session_state.result = None
            st.rerun()

plan, topics = None, []
try:
    plan, topics = load_plan()
except db.DatabaseError as exc:
    st.error(f"Could not load your plan: {exc}")


# ---------- pages ----------
def page_home():
    st.title("🎓 AI Personalized Learning Coach")
    st.write(
        "Tell the coach your goal, your current level and how much time you have. It builds a "
        "day-wise study plan, quizzes you topic by topic, scores your answers, spots weak areas "
        "and recommends what to study next. Everything is saved, so you can come back any time."
    )
    c1, c2, c3 = st.columns(3)
    c1.markdown("**1. Set up**\n\nSubject, goal, level, duration and daily time.")
    c2.markdown("**2. Plan & practise**\n\nAI study plan, then short quizzes per topic.")
    c3.markdown("**3. Track**\n\nWeak topics, scores and next steps on your dashboard.")
    if plan:
        st.success(f"Active plan: **{plan['title']}**. Continue on the Practice Quiz page.")


def page_setup():
    st.header("Learner Setup")
    st.caption("Submitting this form generates a new plan. Earlier plans stay saved.")
    last = plan or {}
    with st.form("setup"):
        subject = st.text_input("Subject", value=last.get("subject", ""),
                                placeholder="e.g. Python")
        goal = st.text_area("Learning goal", value=last.get("goal", ""),
                            placeholder="e.g. Learn Python fundamentals")
        level = st.selectbox("Current level", lp.LEVELS,
                             index=lp.LEVELS.index(last["level"]) if last.get("level") in lp.LEVELS else 0)
        c1, c2 = st.columns(2)
        days = c1.number_input("Target duration (days)", 1, 60, int(last.get("duration_days", 7)))
        minutes = c2.number_input("Study time per day (minutes)", 10, 480,
                                  int(last.get("daily_minutes", 45)), step=5)
        submitted = st.form_submit_button("Generate study plan", type="primary")
    if not submitted:
        return
    profile = {"subject": subject.strip(), "goal": goal.strip(), "level": level,
               "duration_days": int(days), "daily_minutes": int(minutes)}
    errors = lp.validate_profile(profile["subject"], profile["goal"], level,
                                 profile["duration_days"], profile["daily_minutes"])
    if errors:
        for e in errors:
            st.error(e)
        return
    try:
        with st.spinner("Creating your personalised plan..."):
            new_plan = lp.generate_plan(get_ai(), profile)
        plan_id = db.save_plan(profile, new_plan)
    except AIServiceError as exc:
        st.error(str(exc))
        st.button("Retry")  # clicking reruns the app; the form values are kept
        return
    except db.DatabaseError as exc:
        st.error(f"Your plan was generated but could not be saved: {exc}")
        return
    st.session_state.plan_id = plan_id
    st.session_state.quiz = None
    st.session_state.result = None
    st.success("Plan created! Open the **Study Plan** page from the sidebar.")


def page_plan():
    st.header("Study Plan")
    if not plan:
        return need_plan_message()
    st.subheader(plan["title"])
    st.caption(f"{plan['subject']} • {plan['level']} • {plan['duration_days']} days • "
               f"{plan['daily_minutes']} min/day • created {plan['created_at']}")
    for t in topics:
        with st.expander(f"Day {t['day']}: {t['title']}  —  {STATUS_LABEL[t['status']]}  "
                         f"({t['estimated_minutes']} min)"):
            st.markdown("**Objectives**")
            st.markdown("\n".join(f"- {o}" for o in t["objectives"]))
            st.markdown("**Practice activities**")
            st.markdown("\n".join(f"- {a}" for a in t["activities"]))
    st.divider()
    st.markdown("**Goal or schedule changed?** Use *Learner Setup* to regenerate the plan, or delete this one:")
    if st.button("🗑️ Delete this plan"):
        try:
            db.delete_plan(plan["id"])
        except db.DatabaseError as exc:
            st.error(str(exc))
            return
        st.session_state.plan_id = db.get_latest_plan_id()
        st.session_state.quiz = None
        st.session_state.result = None
        st.rerun()


def start_quiz(topic, harder=False):
    try:
        with st.spinner("Generating quiz..."):
            questions = qm.generate_quiz(get_ai(), plan, topic, harder=harder)
    except AIServiceError as exc:
        st.error(str(exc))
        return
    st.session_state.nonce += 1
    st.session_state.quiz = {"topic_id": topic["id"], "questions": questions,
                             "nonce": st.session_state.nonce}
    st.session_state.result = None
    st.rerun()


def submit_quiz(topic, quiz, answers):
    scored = qm.score_quiz(quiz["questions"], answers)
    pct = scored["percentage"]
    next_topic = qm.next_pending_topic(topics, topic["id"])
    rec = qm.recommend(topic["title"], pct, next_topic)
    tips = None
    try:
        tips = get_ai().generate_text_feedback(qm.build_feedback_prompt(plan, topic, scored))
    except Exception:
        tips = None
    try:
        db.save_attempt(plan["id"], topic["id"], scored["score"], scored["total"],
                        quiz["questions"], answers, qm.status_for(pct))
    except db.DatabaseError as exc:
        st.error(f"Could not save this attempt: {exc}")
        return
    st.session_state.result = {"topic_id": topic["id"], "scored": scored, "rec": rec, "tips": tips}
    st.session_state.quiz = None
    st.rerun()


def show_result(res):
    scored, rec = res["scored"], res["rec"]
    st.subheader(f"Score: {scored['score']} / {scored['total']} ({scored['percentage']:.0%})")
    box = {"strong": st.success, "moderate": st.warning, "weak": st.error}[rec["level"]]
    box(rec["message"])
    if res["tips"]:
        st.info(f"💡 {res['tips']}")
    st.markdown("### Review")
    for i, r in enumerate(scored["results"], start=1):
        icon = "✅" if r["is_correct"] else "❌"
        with st.expander(f"{icon} Q{i}. {r['question']}", expanded=not r["is_correct"]):
            chosen = "No answer" if r["chosen"] is None else r["options"][r["chosen"]]
            st.write(f"**Your answer:** {chosen}")
            st.write(f"**Correct answer:** {r['options'][r['correct_index']]}")
            if r["explanation"]:
                st.write(f"**Why:** {r['explanation']}")


def page_quiz():
    st.header("Practice Quiz")
    if not plan:
        return need_plan_message()
    by_id = {t["id"]: t for t in topics}
    quiz = st.session_state.quiz
    default_idx = 0
    if quiz and quiz["topic_id"] in by_id:
        default_idx = list(by_id).index(quiz["topic_id"])
    elif st.session_state.result and st.session_state.result["topic_id"] in by_id:
        default_idx = list(by_id).index(st.session_state.result["topic_id"])
    topic_id = st.selectbox(
        "Choose a topic", list(by_id), index=default_idx,
        format_func=lambda i: f"Day {by_id[i]['day']}: {by_id[i]['title']}  ({STATUS_LABEL[by_id[i]['status']]})")
    topic = by_id[topic_id]

    if quiz and quiz["topic_id"] != topic_id:
        st.session_state.quiz = quiz = None
    if st.session_state.result and st.session_state.result["topic_id"] != topic_id:
        st.session_state.result = None

    if quiz is None:
        c1, c2 = st.columns(2)
        if c1.button("Generate quiz", type="primary"):
            start_quiz(topic)
        if topic["status"] in ("completed", "in_progress") and c2.button("Generate harder quiz"):
            start_quiz(topic, harder=True)
        if st.session_state.result:
            show_result(st.session_state.result)
        past = db.get_attempts(plan["id"], topic_id)
        if past:
            st.markdown("### Attempt history for this topic")
            st.dataframe(pd.DataFrame([{"Date": a["taken_at"], "Score": f"{a['score']}/{a['total']}",
                                        "Percent": f"{a['percentage']:.0%}"} for a in past]),
                         hide_index=True, width="stretch")
        return

    st.write(f"**{topic['title']}** — answer all questions, then submit.")
    with st.form(f"quiz_{quiz['nonce']}"):
        answers = []
        for i, q in enumerate(quiz["questions"]):
            choice = st.radio(f"{i + 1}. {q['question']}", range(4), index=None,
                              format_func=lambda k, q=q: q["options"][k],
                              key=f"q_{quiz['nonce']}_{i}")
            answers.append(choice)
        done = st.form_submit_button("Submit answers", type="primary")
    if done:
        if any(a is None for a in answers):
            st.warning("Please answer every question before submitting.")
        else:
            submit_quiz(topic, quiz, answers)


def page_dashboard():
    st.header("Progress Dashboard")
    if not plan:
        return need_plan_message()
    attempts = db.get_attempts(plan["id"])
    done = sum(t["status"] == "completed" for t in topics)
    revise = sum(t["status"] == "needs_revision" for t in topics)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Completed topics", f"{done}/{len(topics)}")
    c2.metric("Needs revision", revise)
    c3.metric("Quiz attempts", len(attempts))
    c4.metric("Average score", f"{sum(a['percentage'] for a in attempts) / len(attempts):.0%}"
              if attempts else "—")
    st.progress(done / len(topics) if topics else 0.0)

    st.subheader("Next actions")
    for a in qm.next_actions(topics):
        st.markdown(f"- {a}")

    st.subheader("Topics")
    st.dataframe(pd.DataFrame([{
        "Day": t["day"], "Topic": t["title"], "Status": STATUS_LABEL[t["status"]],
        "Attempts": t["attempts"],
        "Last score": f"{t['last_pct']:.0%}" if t["last_pct"] is not None else "—",
        "Best score": f"{t['best_pct']:.0%}" if t["best_pct"] is not None else "—",
    } for t in topics]), hide_index=True, width="stretch")

    st.subheader("Recent quiz scores")
    if not attempts:
        st.caption("No quizzes taken yet.")
        return
    df = pd.DataFrame([{"Date": a["taken_at"], "Topic": a["topic"],
                        "Score": f"{a['score']}/{a['total']}", "Percent": a["percentage"] * 100}
                       for a in attempts])
    st.dataframe(df.head(15).assign(Percent=lambda d: d["Percent"].round().astype(int).astype(str) + "%"),
                 hide_index=True, width="stretch")
    st.line_chart(df.iloc[::-1].reset_index(drop=True)["Percent"], y_label="Score (%)")


{"Home": page_home, "Learner Setup": page_setup, "Study Plan": page_plan,
 "Practice Quiz": page_quiz, "Progress Dashboard": page_dashboard}[page]()
