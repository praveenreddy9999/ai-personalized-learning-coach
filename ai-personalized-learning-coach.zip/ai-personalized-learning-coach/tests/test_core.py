import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import database as db
import learning_plan as lp
import quiz_manager as qm
from ai_service import AIService, AIServiceError, extract_json

PROFILE = {"subject": "Python", "goal": "Learn basics", "level": "Beginner",
           "duration_days": 3, "daily_minutes": 45}


def fake_plan(days=3, minutes=45):
    return json.dumps({"title": "Plan", "topics": [
        {"day": d, "title": f"Topic {d}", "objectives": ["a"], "estimated_minutes": minutes,
         "practice_activities": ["b"]} for d in range(1, days + 1)]})


def fake_quiz(n=5):
    return json.dumps({"questions": [
        {"question": f"Q{i}", "options": ["a", "b", "c", "d"], "correct_index": i % 4,
         "explanation": "because"} for i in range(n)]})


def ai(reply):
    replies = reply if isinstance(reply, list) else [reply]
    state = {"i": 0}

    def gen(_):
        r = replies[min(state["i"], len(replies) - 1)]
        state["i"] += 1
        if isinstance(r, Exception):
            raise r
        return r
    return AIService(generate_fn=gen, retry_delay=0)


@pytest.fixture(autouse=True)
def tmp_db(tmp_path, monkeypatch):
    monkeypatch.setattr(db, "DB_PATH", str(tmp_path / "t.db"))
    db.init_db()


# --- validation / setup
def test_missing_subject_or_goal():
    errs = lp.validate_profile("", "", "Beginner", 7, 45)
    assert len(errs) == 2


def test_valid_setup_generates_plan_matching_profile():
    plan = lp.generate_plan(ai(fake_plan()), PROFILE)
    assert len(plan["topics"]) == 3
    assert all(t["estimated_minutes"] <= 45 for t in plan["topics"])


def test_plan_minutes_clamped_to_daily_time():
    plan = lp.generate_plan(ai(fake_plan(minutes=120)), PROFILE)
    assert all(t["estimated_minutes"] == 45 for t in plan["topics"])


# --- invalid LLM / API failure
def test_invalid_response_retries_then_succeeds():
    plan = lp.generate_plan(ai(["not json", fake_plan()]), PROFILE)
    assert plan["topics"]


def test_invalid_response_raises_clean_error():
    with pytest.raises(AIServiceError):
        lp.generate_plan(ai("garbage"), PROFILE)


def test_api_failure_raises_clean_error():
    with pytest.raises(AIServiceError):
        lp.generate_plan(ai(AIServiceError("network down")), PROFILE)


def test_extract_json_handles_fences():
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}


# --- quiz
def test_quiz_validation_rejects_bad_correct_index():
    bad = json.loads(fake_quiz())
    bad["questions"][0]["correct_index"] = 9
    with pytest.raises(AIServiceError):
        qm.generate_quiz(ai(json.dumps(bad)), PROFILE, {"title": "T", "objectives": ["o"]})


def test_score_from_answer_key():
    qs = json.loads(fake_quiz())["questions"]
    answers = [q["correct_index"] for q in qs]
    assert qm.score_quiz(qs, answers)["score"] == 5
    answers[0] = (answers[0] + 1) % 4
    answers[1] = (answers[1] + 1) % 4
    s = qm.score_quiz(qs, answers)
    assert (s["score"], s["total"]) == (3, 5)


def test_low_score_recommends_revision_and_high_moves_on():
    low = qm.recommend("Loops", 0.4, "Lists")
    high = qm.recommend("Loops", 1.0, "Lists")
    assert low["action"] == "revise" and qm.status_for(0.4) == "needs_revision"
    assert high["action"] == "advance" and qm.status_for(1.0) == "completed"
    assert "Lists" in high["message"]


# --- database persistence & history
def test_persistence_and_repeated_attempts():
    plan = lp.generate_plan(ai(fake_plan()), PROFILE)
    pid = db.save_plan(PROFILE, plan)
    topic = db.get_topics(pid)[0]
    qs = json.loads(fake_quiz())["questions"]
    db.save_attempt(pid, topic["id"], 2, 5, qs, [0] * 5, qm.status_for(0.4))
    db.save_attempt(pid, topic["id"], 5, 5, qs, [0] * 5, qm.status_for(1.0))
    # "restart": a fresh connection reads the same data
    assert db.get_latest_plan_id() == pid
    t = db.get_topics(pid)[0]
    assert t["attempts"] == 2 and t["status"] == "completed"
    assert t["best_pct"] == 1.0 and t["last_pct"] == 1.0
    assert len(db.get_attempts(pid)) == 2


def test_next_actions_flags_weak_topic():
    plan = lp.generate_plan(ai(fake_plan()), PROFILE)
    pid = db.save_plan(PROFILE, plan)
    t = db.get_topics(pid)[0]
    db.save_attempt(pid, t["id"], 2, 5, [], [], qm.status_for(0.4))
    actions = qm.next_actions(db.get_topics(pid))
    assert "Revise" in actions[0] and "Topic 1" in actions[0]
