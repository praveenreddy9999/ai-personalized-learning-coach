# AI Personalized Learning Coach

A Streamlit app that builds a personalised study plan with an LLM (Google Gemini), quizzes you on each topic,
scores answers **in Python from the answer key**, flags weak topics, recommends next steps and stores everything in SQLite.

## Features
| Requirement | Where |
|---|---|
| Learner setup + validation (FR-01, FR-12) | `app.py`, `learning_plan.validate_profile` |
| Day-wise plan generation / regeneration (FR-02, FR-03) | `learning_plan.py` |
| Topic selection, 5-question MCQ quiz (FR-04, FR-05) | `quiz_manager.py`, `app.py` |
| Python scoring + feedback (FR-06, FR-07) | `quiz_manager.score_quiz` |
| Weak topics + recommendations (FR-08, FR-09) | `quiz_manager.status_for / recommend / next_actions` |
| Persistence of plans, attempts, status (FR-10) | `database.py` |
| Dashboard (FR-11) | `app.py` → Progress Dashboard |

## Setup
```bash
git clone <your-repo-url> && cd ai-personalized-learning-coach
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then paste your Gemini API key (free at https://aistudio.google.com/apikey)
streamlit run app.py
```
Run the tests (no API key needed, the LLM is mocked): `pytest -q`

## Architecture
```
app.py            Streamlit UI (5 pages), session state, error display
ai_service.py     Gemini call, JSON extraction, retry-on-invalid-output, API error handling
learning_plan.py  Plan prompt + schema validation + input validation
quiz_manager.py   Quiz prompt + validation, scoring, thresholds, recommendations
database.py       SQLite schema and queries
```

### Database
- `plans(id, title, subject, goal, level, duration_days, daily_minutes, created_at)`
- `topics(id, plan_id→plans, day, title, objectives, estimated_minutes, activities, status, updated_at)`
- `quiz_attempts(id, plan_id→plans, topic_id→topics, taken_at, score, total, percentage, questions_json, answers_json)`

Every attempt is a separate row, so history is never overwritten. Deleting a plan cascades.

### Prompt design
System instruction forces JSON-only output and forbids claiming mastery. Each prompt states the exact schema,
the learner's level, duration and daily minutes. Outputs are validated in Python; on invalid output the app
retries up to 3 times, feeding the validation error back to the model, then shows a friendly error.

### Scoring and recommendation logic
Score = number of answers matching `correct_index` (computed in Python). Status after a quiz:
`>= 80%` completed, `60–79%` in progress, `< 60%` needs revision. Messages note that one quiz isn't proof of mastery.
The LLM is only asked for optional short study tips (given the already-computed score); failure there is non-fatal.

## Error handling
Missing inputs, empty/malformed/invalid model JSON, missing API key, network/quota errors and SQLite errors all
produce a readable message; the app never crashes and the learner can retry.

## Limitations
- Quiz quality depends on the LLM; questions are not fact-checked.
- Short 5-question quizzes are a rough signal only.
- No user accounts: one local SQLite database per deployment.
- Streamlit Community Cloud storage is ephemeral, so for permanent history use a persistent host or external DB.

## Deploy (get a public link)
1. Push this folder to a GitHub repo (`.env` and `*.db` are git-ignored).
2. Go to https://share.streamlit.io → New app → pick the repo, branch, `app.py`.
3. In *Advanced settings → Secrets* add: `GEMINI_API_KEY = "your key"`.
